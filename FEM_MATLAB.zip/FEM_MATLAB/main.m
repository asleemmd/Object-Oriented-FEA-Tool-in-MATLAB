clc;
clear;
close all;

controller = STRController();
%viewer = Viewer();

node1 = controller.AddSTRNode(0,0,0);
node2 = controller.AddSTRNode(0,0,5);
node3 = controller.AddSTRNode(10,0,5);
node4 = controller.AddSTRNode(10,0,0);

line1 = controller.AddSTRLine(node1, node2);
line2 = controller.AddSTRLine(node2,node3);
line3 = controller.AddSTRLine(node3,node4);
line4 = controller.AddSTRLine(node4,node1);

support1 = controller.AddSTRSupport('Pinned1',1e15,1e15,1e15,1e-4,1e-4,1e-4);
support2 = controller.AddSTRSupportFixed('Fixed');
support3 = controller.AddSTRSupportPinned('Pinned2');
support4 = controller.AddSTRSupportRoller('Roller');

section1 = controller.AddSTRSectionRectangular('300x500', 0.30, 0.50);
section2 = controller.AddSTRSection('section2', 1,2,3,4);


controller.ApplySupport(node1, support1);
controller.ApplySection(line1, section1)
controller.ApplySection(line3, section1)
controller.ApplySection(line2, section2)



controller.ToString();
%viewer.Render(controller);






