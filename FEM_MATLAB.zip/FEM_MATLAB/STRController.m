classdef STRController < handle
    properties
        Epsilon = 1e-6;
        STRNodeId = 0;
        STRLineId = 0;
        STRSupportId = 0;
        STRSectionId = 0;
        STRNodes;
        STRLines;
        STRSupports;
        STRSections
    end
    methods
        function obj = STRController()
        end
        function node = AddSTRNode(obj, x, y, z)
            %Check for duplicate nodes
            for i = 1:length(obj.STRNodes)
                existingNode = obj.STRNodes(i);
                if (abs(existingNode.X - x) < obj.Epsilon && ...
                        abs(existingNode.Y - y) < obj.Epsilon && ...
                        abs(existingNode.Z - z) < obj.Epsilon)
                    disp('Node Exists')
                    node = existingNode;
                    return;
                end
            end

            obj.STRNodeId = obj.STRNodeId + 1;
            id = obj.STRNodeId;
            node = STRNode (id, x ,y, z);
            obj.STRNodes = [obj.STRNodes, node];
        end
        function line = AddSTRLine(obj,node1,node2)
            %TODO check for duplicate line
            for i = 1:length(obj.STRLines)
                existingLine = obj.STRLines(i);
                if(existingLine.Node1.Id == node1.Id && ...
                        existingLine.Node2.Id == node2.Id)
                    line = existingLine;
                    return;
                end
                if(existingLine.Node2.Id == node1.Id && ...
                        existingLine.Node1.Id == node2.Id)
                    line = existingLine;
                    return;
                end
            end
            obj.STRLineId = obj.STRLineId + 1;
            id = obj.STRLineId;
            line = STRLine(id, node1, node2);
            obj.STRLines = [obj.STRLines, line];
        end
        %% Section Definition Region
        function section = AddSTRSection(obj, name, ax, ix, iy, iz)
            obj.STRSectionId = obj.STRSectionId + 1;
            id = obj.STRSectionId;
            section = STRSection(id, name, ax, ix, iy,iz);
            obj.STRSections = [obj.STRSections, section];
        end
        function section = AddSTRSectionRectangular(obj, name, width, height)
            % Let's calculate section properties
            ax = width * height;
            iy = 1.0/12.0 * width * height^3;
            iz = .0/12.0 * height * width^3;
            ix = iy + iz; %PLACEHOLDER
            obj.STRSectionId = obj.STRSectionId + 1;
            id = obj.STRSectionId;
            section = STRSection(id, name, ax, ix, iy,iz);
            obj.STRSections = [obj.STRSections, section];
        end
        function ApplySection(~,line,section)
            line.Section = section;
        end
        function DeleteSection(~,line)
            line.Section = [];
        end
        %% Support Region
        function support= AddSTRSupport(obj, name, kux, kuy, kuz, krx, kry, krz)
            obj.STRSupportId = obj.STRSupportId + 1;
            id = obj.STRSupportId;
            support = STRSupport(id, name, kux, kuy, kuz, krx, kry, krz);
            obj.STRSupports = [obj.STRSupports, support];
        end
        function support = AddSTRSupportFixed(obj, name)
            obj.STRSupportId = obj.STRSupportId + 1;
            id = obj.STRSupportId;
            support = STRSupport(id, name, ...
                STRSupport.KURigid, ...
                STRSupport.KURigid, ...
                STRSupport.KURigid, ...
                STRSupport.KRRigid, ...
                STRSupport.KRRigid, ...
                STRSupport.KRRigid);
            obj.STRSupports = [obj.STRSupports, support];
        end
        function support = AddSTRSupportPinned(obj, name)
            obj.STRSupportId = obj.STRSupportId + 1;
            id = obj.STRSupportId;
            support = STRSupport(id, name, ...
                STRSupport.KURigid, ...
                STRSupport.KURigid, ...
                STRSupport.KURigid, ...
                STRSupport.KRFree, ...
                STRSupport.KRFree, ...
                STRSupport.KRFree);
            obj.STRSupports = [obj.STRSupports, support];
        end
        function support = AddSTRSupportRoller(obj, name) %allows movement in horizontal suface x and y
            obj.STRSupportId = obj.STRSupportId + 1;
            id = obj.STRSupportId;
            support = STRSupport(id, name, ...
                STRSupport.KUFree, ...
                STRSupport.KUFree, ...
                STRSupport.KURigid, ...
                STRSupport.KRFree, ...
                STRSupport.KRFree, ...
                STRSupport.KRFree);
            obj.STRSupports = [obj.STRSupports, support];
        end
        function ApplySupport(~, node, support)
            node.Support = support;
        end
        function DeleteSupport(~, node)
            node.Support = [];
        end
        %% Reporting
        function ToString(obj)
            fprintf('Model has %i nodes and %i lines.\n',length(obj.STRNodes), length(obj.STRLines));
            fprintf('===============\nNodes\n');
            for i = 1:length(obj.STRNodes)
                targetNode = obj.STRNodes(i);
                targetNode.ToString();
            end
            fprintf('===============\nLines\n');
            for i = 1:length(obj.STRLines)
                targetLine = obj.STRLines(i);
                targetLine.ToString();
                fprintf('\n');
            end
            fprintf('===============\nSupports\n');
            for i = 1:length(obj.STRSupports)
                targetSupport = obj.STRSupports(i);
                targetSupport.ToString();
            end
            fprintf('===============\nSections\n');
            for i = 1:length(obj.STRSections)
                targetSection = obj.STRSections(i);
                targetSection.ToString();
            end
        end
    end
end